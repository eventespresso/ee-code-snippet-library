<?php
/*
Plugin Name: EE Custom Functions - Ticket selector iframe inline styles
Description: This plugin can be used to hold inline styles output on the ticket selector iFrame.
*/

add_action(
    'AHEE__EventEspresso_modules_ticket_selector_TicketSelectorIframe__construct__complete',
    'tw_ee_add_inline_styles_ticket_selector_iframe'
);
function tw_ee_add_inline_styles_ticket_selector_iframe($TicketSelectorIframe) {
    $TicketSelectorIframe->addInlineStyles(
        'ticket_selector',
        'input.ticket-selector-submit-btn {
            background-color: red;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
        }'
    );
}
