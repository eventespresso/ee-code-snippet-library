<?php
/*
Plugin Name: Event Espresso - Payment Method Surcharges
Description: Adds surcharges settings to Event Espresso payment methods
*/

add_filter('FHEE__EE_Payment_Method_Form___construct__options_array', 'tw_ee_add_payment_method_surcharge_setting', 20, 2);
function tw_ee_add_payment_method_surcharge_setting($options, $form) {
    $options['extra_meta_inputs']['surcharge_type'] = new EE_Select_Input(
        [
            1 => 'Percentage Surcharge',
            0 => 'Fixed Surcharge'
        ],
        [
            'html_label_text' => esc_html__(
                'Payment method surcharge type:',
                'event_espresso'
            ),
            'html_help_text'  => esc_html__(
                'Determine if the surcharged is percentage or fixed.',
                'event_espresso'
            ),
            'default'         => 'percentage',
        ]
    );
    $options['extra_meta_inputs']['surcharge_value'] = new EE_Text_Input([
        'html_label_text' => esc_html__(
            'Payment method surcharge value:',
            'event_espresso'
        ),
    ]);
    $options['extra_meta_inputs']['surcharge_name'] = new EE_Text_Input([
        'html_label_text' => esc_html__(
            'Payment method surcharge name:',
            'event_espresso'
        ),
        'html_help_text'  => esc_html__(
            'The name of the surcharge, this value is shown to users.',
            'event_espresso'
        ),
    ]);
    if(isset($options['include'])) {
        $options['include'] = array_merge($options['include'], ['surcharge_type', 'surcharge_value','surcharge_name']);
    }
    return $options;
}

function tw_ee_spco_add_surcharge_on_payment_method_switch( EE_SPCO_Reg_Step $payment_options_reg_step ) {

    $cart = $payment_options_reg_step->checkout->cart;
    if( ! $cart instanceof EE_Cart ) {
        return;
    }

    $transaction = $payment_options_reg_step->checkout->transaction;
    if( ! $transaction instanceof EE_Transaction ) {
        return;
    }

    $total_line_item = $payment_options_reg_step->checkout->cart->get_grand_total();
    if ( ! $total_line_item instanceof EE_Line_Item) {
        return;
    }
    
    //Delete existing modifier in case page is refreshed or payment method changed.
    EEM_Line_Item::instance()->delete(
        [
            [
                'TXN_ID'   => $transaction->ID(),
                'LIN_type' => EEM_Line_Item::type_line_item,
                'OBJ_type' => 'Surcharge',
            ]
        ]
    );

    // Get the user selected payment method
    $payment_method = $payment_options_reg_step->checkout->payment_method;
    if( $payment_method instanceof EE_Payment_Method ) {
        // Check if payment method has a surcharge set
        $surcharge_value        = $payment_method->get_extra_meta('surcharge_value', true);
        $surcharge_percentage   = $payment_method->get_extra_meta('surcharge_type', true);
        $surcharge_name         = $payment_method->get_extra_meta('surcharge_name', true);

        if( $surcharge_value ) {
            if( $surcharge_percentage ) {
                $line_item = EEH_Line_Item::add_percentage_based_item(
                    $total_line_item,
                    $surcharge_name ?: 'Processing Fee',
                    $surcharge_value,
                    '',
                    false,
                    null,
                    true
                );
            } else {
                $line_item = EEH_Line_Item::add_unrelated_item(
                    $total_line_item,
                    $surcharge_name ?: 'Processing Fee',
                    $surcharge_value,
                    '',
                    1,
                    false,
                    null,
                    true,
                    false
                );

            }
            $line_item->set_OBJ_type('Surcharge');
            $line_item->save();
        }
    }

    // Recalculate total && transaction
    $total_line_item->recalculate_total_including_taxes();
    $registration_processor = EE_Registry::instance()->load_class('Registration_Processor');
    $registration_processor->update_registration_final_prices($transaction);
    $payment_options_reg_step->checkout->amount_owing = $transaction->remaining();
}
add_action( 'AHEE__Single_Page_Checkout__after_payment_options__switch_payment_method', 'tw_ee_spco_add_surcharge_on_payment_method_switch', 10, 1 );

// Filter SPCO Display strategy to clean up the output of 'Surcharge' rows.
add_filter('FHEE__EE_SPCO_Line_Item_Display_Strategy__item_row__name', 'tw_ee_filter_SPCO_display_strategy_for_surcharges', 10, 2);
function tw_ee_filter_SPCO_display_strategy_for_surcharges( $name_and_desc, $line_item ) {
    if($line_item->OBJ_type() === 'Surcharge') {
        return $line_item->name();
    }
    return $name_and_desc;
}

// Force the page to reload after each payment method switch.
function tw_ee_refresh_checkout_on_payment_method_change() {
  wp_add_inline_script( 
    'single_page_checkout',
    'jQuery(function () {
        SPCO.main_container.on( \'spco_switch_payment_methods\', function() { 
            SPCO.do_before_sending_ajax();
            window.location.reload(); 
        });
    });'
  );
}
add_action( 'wp_enqueue_scripts', 'tw_ee_refresh_checkout_on_payment_method_change', 11 );
